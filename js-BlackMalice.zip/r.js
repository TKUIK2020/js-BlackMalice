let http = require("http");
const fs= require('fs');
http.createServer(function(request, response) {
  var generateImage = require('random-image-creator');
response.writeHead(200, {"Content-Type": "text/html"});
fs.readFile('Document.html','utf8',function(error,data){
  if (error){
    response.write('error');
  }
  else{
    response.write(data);
    response.end();
  }
})
}).listen(process.env.PORT);
